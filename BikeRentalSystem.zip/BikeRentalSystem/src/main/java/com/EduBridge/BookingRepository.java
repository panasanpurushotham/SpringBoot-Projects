package com.EduBridge;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BookingRepository extends JpaRepository<Booking, Long> {
	    List<Booking> findByProduct(Product product);
	}


