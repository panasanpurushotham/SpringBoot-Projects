package com.EduBridge;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AddbikeRepository extends JpaRepository<AddbikeModel,Integer>  {

}
