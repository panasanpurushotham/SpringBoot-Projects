package com.EduBridge;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BRSRepository extends JpaRepository<BRSModel,Integer>{


}
